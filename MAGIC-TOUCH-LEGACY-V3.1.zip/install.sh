SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=false

REPLACE="
"

ui_print "_________________________"
ui_print ""
ui_print " MAGIC TOUCH LEGACY "
ui_print "_________________________"
ui_print " Dev : HenVx "
ui_print " Ver : 3.1 Stabil "
ui_print ""
ui_print ""
ui_print ""
ui_print ""
ui_print "Done"