#!/system/bin/sh
# Please don't hardcode /magisk/modname/... ; instead, please use $MODDIR/...
# This will make your scripts compatible even if Magisk change its mount point in the future
MODDIR=${0%/*}

while [ `getprop vendor.post_boot.parsed` != "1" ]; do
    sleep 1s
done

sleep 10s

echo '7035' > /sys/class/touch/switch/set_touchscreen
echo '8002' > /sys/class/touch/switch/set_touchscreen
echo '11000' > /sys/class/touch/switch/set_touchscreen
echo '13060' > /sys/class/touch/switch/set_touchscreen
echo '14005' > /sys/class/touch/switch/set_touchscreen
